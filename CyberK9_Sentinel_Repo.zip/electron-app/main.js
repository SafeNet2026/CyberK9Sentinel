// Electron entry point
console.log('CyberK9 Sentinel launched');